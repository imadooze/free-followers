// عرض الصفحة المطلوبة فقط
function showPage(id) {
  const pages = document.querySelectorAll('.page');
  pages.forEach(page => {
    page.classList.remove('active');
    page.style.display = 'none';
  });

  const targetPage = document.getElementById(id);
  if (targetPage) {
    targetPage.classList.add('active');
    targetPage.style.display = 'block';
    window.scrollTo(0, 0); // لتأكد من عرض الصفحة من الأعلى
  }
}

// التسبيح
let tasbeehCount = 0;

function updateTasbeehUI() {
  const countElement = document.getElementById("tasbeehCount");
  if (countElement) {
    countElement.innerText = tasbeehCount;
  }
}

function incrementTasbeeh() {
  tasbeehCount++;
  updateTasbeehUI();
  localStorage.setItem("tasbeehCount", tasbeehCount);
}

function resetTasbeeh() {
  tasbeehCount = 0;
  updateTasbeehUI();
  localStorage.removeItem("tasbeehCount");
}

// الوضع المظلم
function toggleDarkMode() {
  document.body.classList.toggle('dark-mode');
}

// فتح روابط
function openHelp() {
  window.open("https://www.instagram.com/was_iya1?igsh=eHNzcHpwYjUzdWpo", "_blank");
}

function openTerms() {
  showPage('privacy-policy-page');
}

// تحميل الصفحة
document.addEventListener("DOMContentLoaded", () => {
  // عرض الصفحة الرئيسية أولاً
  showPage('home');

  // تحميل عدد التسبيحات من التخزين المحلي
  const savedCount = localStorage.getItem("tasbeehCount");
  if (savedCount !== null && !isNaN(savedCount)) {
    tasbeehCount = parseInt(savedCount);
    updateTasbeehUI();
  }

  // استجابة الشاشات الصغيرة: جعل جميع .page بعرض 100% تلقائيًا
  document.querySelectorAll('.page').forEach(page => {
    page.style.width = "100%";
  });
